declare const nunjucks: {
    renderString(tmpl:string,data:object): string
  }