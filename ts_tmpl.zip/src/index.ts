//  /// <reference path="global.d.ts" />
console.log('-= ʕ ᵔᴥᵔ ʔ =-')

const res = nunjucks.renderString('Hello {{ username }}', { username: 'Ferahar' });

function foo(text: string): void {
    console.log(text);
}

foo(res)
