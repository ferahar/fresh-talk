export class DomListener {

    constructor(root, listeners = []) {
      if (!root) {
        throw new Error('No root provide for Doomlistener')
      }
      this.root = root
      this.listeners = listeners
    }
  
    initDomListeners() {
      this.listeners.forEach(listener => {
        const method = getMethodName(listener)
        if (!this[method]) {
          throw new Error(`Method ${method} is not implemented in ${this.name} Component`)
        }
        // replace
        this[method] = this[method].bind(this)
        // this.root.el.addEventListener(listener, this[eventName])
        this.root.on(listener, this[method].bind(this))
      })
    }
  
    removeDomListeners() {
      this.listeners.forEach(listener => {
        const method = getMethodName(listener)
        this.root.off(listener, this[method])
      })
    }
  }
  
  function getMethodName(eventName) {
    return 'on'+eventName[0].toUpperCase()+eventName.slice(1)
  }
  