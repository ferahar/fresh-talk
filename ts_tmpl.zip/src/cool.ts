export class Cool {
    name: string;
    constructor(name: string) {
        this.name = name;
    }
}