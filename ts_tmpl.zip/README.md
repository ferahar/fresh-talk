
## WEB-CHAT
Демо: <a href="https://ferahar-msg.netlify.app/">Ferahar-msg</a>
- проект в разработке
- js learning

## UX/UI
Файл Figma <a href="https://www.figma.com/file/KKfDj7ZXqhzazW3yBuTyrG/ferahar-msgr?node-id=0%3A1&viewport=466%2C373%2C0.47879621386528015">ferahar-msgg</a>

## УСТАНОВКА
- `npm install` — установка стабильной версии,
- `npm start` — запуск версии для разработчика
